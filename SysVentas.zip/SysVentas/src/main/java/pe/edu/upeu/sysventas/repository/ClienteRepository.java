package pe.edu.upeu.sysventas.repository;

import pe.edu.upeu.sysventas.model.Cliente;

public interface ClienteRepository extends ICrudGenericoRepository<Cliente,String>{
}
