package pe.edu.upeu.sysventas.service;

import pe.edu.upeu.sysventas.model.CompraDetalle;

public interface ICompraDetalleService extends ICrudGenericoService<CompraDetalle,Long>{
}
