package pe.edu.upeu.sysventas.service;

import pe.edu.upeu.sysventas.model.VentaDetalle;

public interface IVentaDetalleService extends ICrudGenericoService<VentaDetalle,Long>{
}
