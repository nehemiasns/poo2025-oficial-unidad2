package pe.edu.upeu.sysventas.repository;


import pe.edu.upeu.sysventas.model.Compra;

public interface CompraRepository extends ICrudGenericoRepository<Compra,Long>{
}
