package pe.edu.upeu.sysventas.repository;

import pe.edu.upeu.sysventas.model.CompCarrito;

public interface CompCarritoRepository extends ICrudGenericoRepository<CompCarrito,Long>{
}
