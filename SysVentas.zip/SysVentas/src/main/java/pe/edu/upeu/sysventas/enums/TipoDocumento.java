package pe.edu.upeu.sysventas.enums;

public enum TipoDocumento {
    DNI,
    RUC;
}