package pe.edu.upeu.sysventas.repository;

import pe.edu.upeu.sysventas.model.VentaDetalle;

public interface VentaDetalleRepository extends ICrudGenericoRepository<VentaDetalle,Long>{
}
