package pe.edu.upeu.sysventas.service;

import pe.edu.upeu.sysventas.model.Proveedor;

public interface IProveedorService extends  ICrudGenericoService<Proveedor,Long>{
}
