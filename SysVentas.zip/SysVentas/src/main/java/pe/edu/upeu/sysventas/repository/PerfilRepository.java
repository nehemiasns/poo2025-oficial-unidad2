package pe.edu.upeu.sysventas.repository;


import pe.edu.upeu.sysventas.model.Perfil;

public interface PerfilRepository extends  ICrudGenericoRepository<Perfil,Long>{
}
