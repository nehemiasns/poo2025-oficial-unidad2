package pe.edu.upeu.sysventas.repository;


import pe.edu.upeu.sysventas.model.Marca;

public interface MarcaRepository extends  ICrudGenericoRepository<Marca,Long>{
}
