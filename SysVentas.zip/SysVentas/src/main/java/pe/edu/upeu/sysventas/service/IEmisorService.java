package pe.edu.upeu.sysventas.service;

import pe.edu.upeu.sysventas.model.Emisor;

public interface IEmisorService extends  ICrudGenericoService<Emisor,Long>{
}
