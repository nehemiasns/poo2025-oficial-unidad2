package pe.edu.upeu.sysventas.service;

import pe.edu.upeu.sysventas.model.Compra;

public interface ICompraService extends ICrudGenericoService<Compra,Long>{
}
