package pe.edu.upeu.sysventas;

public class RunJavaFx {
    public static void main(String[] args) {
        SysVentasApplication.main(args);
    }
}
