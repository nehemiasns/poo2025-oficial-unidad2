package pe.edu.upeu.sysventas.repository;

import pe.edu.upeu.sysventas.model.Proveedor;

public interface ProveedorRepository extends ICrudGenericoRepository<Proveedor,Long>{
}
