package pe.edu.upeu.sysventas.service;

import pe.edu.upeu.sysventas.model.Perfil;

public interface IPerfilService extends ICrudGenericoService<Perfil,Long>{
}
