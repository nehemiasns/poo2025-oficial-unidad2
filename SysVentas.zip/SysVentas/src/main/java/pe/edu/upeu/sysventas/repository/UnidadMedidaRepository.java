package pe.edu.upeu.sysventas.repository;


import pe.edu.upeu.sysventas.model.UnidadMedida;

public interface UnidadMedidaRepository extends ICrudGenericoRepository<UnidadMedida,Long>{
}
