package pe.edu.upeu.sysventas.repository;

import pe.edu.upeu.sysventas.model.Emisor;

public interface EmisorRepository extends  ICrudGenericoRepository<Emisor,Long>{
}
