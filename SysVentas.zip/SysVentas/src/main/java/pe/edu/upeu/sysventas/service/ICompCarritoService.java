package pe.edu.upeu.sysventas.service;

import pe.edu.upeu.sysventas.model.CompCarrito;

public interface ICompCarritoService extends ICrudGenericoService<CompCarrito,Long>{
}
