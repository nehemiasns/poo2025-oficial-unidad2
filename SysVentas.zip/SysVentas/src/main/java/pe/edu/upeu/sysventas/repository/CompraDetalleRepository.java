package pe.edu.upeu.sysventas.repository;


import pe.edu.upeu.sysventas.model.CompraDetalle;

public interface CompraDetalleRepository extends  ICrudGenericoRepository<CompraDetalle,Long>{
}
